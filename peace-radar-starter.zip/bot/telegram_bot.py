"""Minimal read-only Telegram bot: /status.

Set TELEGRAM_BOT_TOKEN. Run as a separate Render worker if desired.
"""
import os
import requests
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

BASE_URL = os.getenv("PUBLIC_BASE_URL", "http://127.0.0.1:5000")

async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        rows = requests.get(BASE_URL + "/api/status", timeout=10).json()
        if not rows:
            message = "Пока нет опубликованных официальных статусов."
        else:
            message = "\n".join(
                f"• {r['region']}: {r['status']} — {r['title']}"
                for r in rows[:25]
            )
        await update.message.reply_text(message[:4000])
    except Exception:
        await update.message.reply_text("Сервис временно недоступен.")

def main():
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token:
        raise RuntimeError("Set TELEGRAM_BOT_TOKEN")
    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler("status", status))
    app.run_polling()

if __name__ == "__main__":
    main()
