def normalize_text(value):
    return " ".join((value or "").replace("\u00a0", " ").split())
