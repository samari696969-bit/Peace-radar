"""Status is assigned in the trusted source configuration, not guessed from text."""

def public_status_label(status):
    return {
        "info": "Информация",
        "warning": "Предупреждение",
        "all_clear": "Отбой",
        "unknown": "Неизвестно",
    }.get(status, "Неизвестно")
